import pygame, sys, random
from pygame.locals import *
from time import sleep


#arrow keys for movement, "c" to catch gold, "v" to catch weapon,"SPACE" to kill monster
#don't enter traps (purple squares) or you'll dye

#game name
win_sur = pygame.display.set_mode((500,500))
pygame.display.set_caption("Men do not fear swords...they fear monsters!")


#colours
BLACK = (0, 0, 0 )
WHITE = (255, 255, 255 )
#resources
FLOOR = 0
ROCK = 1
TRAP = 2
GRASS = 3
GOLD = 4
WEAPON = 5
ENEMYLBL = 6
EXIT = 7
textures = {
                    FLOOR : pygame.image.load("FLOOR.png"),
                    ROCK : pygame.image.load("ROCK.png"),
                    TRAP : pygame.image.load("TRAP.png"),
                    GRASS : pygame.image.load("GRASS.png"),
                    GOLD : pygame.image.load("GOLD.png"),
                    WEAPON : pygame.image.load("WEAPON.png").convert_alpha(),
                    ENEMYLBL : pygame.image.load("ENEMY.png").convert_alpha(),
                    EXIT : pygame.image.load("EXIT.png").convert_alpha()
                 }
#define resources amount
GOLDqtt = 1
TRAPqtt = 2
ROCKqtt = 10
WEAPONqtt = 1
ENEMYqtt = 1
#criate player inventory
inventory = {
                    GOLD : 0,
                    ENEMYLBL : 0,
                    WEAPON : 0
                  }


#player and enemy images and position
HERO = pygame.image.load("ICHIGO.png").convert_alpha()
playerPos = [0,0]
ENEMY = pygame.image.load("ENEMY.png").convert_alpha()
enemyPos = [9,9] 


#set up game dimensions
TILESIZE = 50
MAPWIDTH = 10
MAPHEIGHT = 10
resources = [GOLD,WEAPON,ENEMYLBL]
tilemap = [[FLOOR for w in range(MAPWIDTH)] for h in range(MAPHEIGHT)]


#set up display and background music
pygame.mixer.init()
pygame.init()
pygame.mixer.music.load("backgroundMusic.mp3")
pygame.mixer.music.play()
win_sur = pygame.display.set_mode((MAPWIDTH*TILESIZE, MAPHEIGHT*TILESIZE + 50))


#font type
INVFONT = pygame.font.Font("freesansbold.ttf", 18)


#define objects positions
for rw in range(MAPHEIGHT):
    for cl in range(MAPWIDTH):
        if rw == 1 and cl == 1:
            tile = EXIT
        else:
            randomNr = random.randint(0, 20)
            if randomNr == 0:
                 if GOLDqtt > 0:
                     tile = GOLD
                     GOLDqtt -= 1
            elif randomNr >= 1 and randomNr <= 2:
                if TRAPqtt > 0:
                     tile = TRAP
                     TRAPqtt -= 1
            elif randomNr >=3 and randomNr <= 4:
                if ROCKqtt > 0:
                    tile = ROCK
                    ROCKqtt -= 1
            elif randomNr >= 7 and randomNr <= 12:
                 tile =GRASS
            elif randomNr == 13:
                 if WEAPONqtt > 0:
                     tile = WEAPON
                     WEAPONqtt -= 1
            else:
                tile = FLOOR
            tilemap[rw][cl] = tile


#draw player and map
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            if event.key == K_q:
                pygame.quit()
                sys.exit()
        #player and enemy movement
        elif event.type == KEYDOWN:
            if event.key == K_RIGHT and playerPos[0] < MAPWIDTH - 1:
                #player right edge
                if tilemap[playerPos[1]][playerPos[0]+1] != ROCK:
                    playerPos[0] += 1
                #enemy left edge
                if tilemap[enemyPos[1]][enemyPos[0]-1] != ROCK:
                    if enemyPos[0] >0:
                        enemyPos[0] -= 1
            if event.key ==K_LEFT and playerPos[0] > 0:
                #player left edge
                if tilemap[playerPos[1]][playerPos[0]-1] != ROCK:
                    playerPos[0] -= 1
                #enemy right edge
                if enemyPos[0] < MAPWIDTH - 1:
                    if tilemap[enemyPos[1]][enemyPos[0]+1] != ROCK:
                        enemyPos[0] += 1
            if event.key == K_UP and playerPos[1] > 0:
                #player upward edge
                if tilemap[playerPos[1]-1][playerPos[0]] != ROCK:
                    playerPos[1] -= 1
                #enemy downward edge
                if enemyPos[1] <MAPHEIGHT - 1:
                    if tilemap[enemyPos[1]+1][enemyPos[0]] != ROCK:
                        enemyPos[1] += 1
            if event.key == K_DOWN and playerPos[1] < MAPHEIGHT - 1:
                #player downward edge
                if tilemap[playerPos[1]+1][playerPos[0]] != ROCK:
                    playerPos[1] += 1
                #enemy upward edge
                if tilemap[enemyPos[1]-1][enemyPos[0]] != ROCK:
                    if enemyPos[1] >0:
                        enemyPos[1] -= 1
            #craft resources        
            if event.key == K_SPACE:
                if enemyPos[1] - playerPos[1] <= 1 and enemyPos[0] - playerPos[0] <= 1:
                    if inventory[WEAPON] == 1:
                        inventory[ENEMYLBL] += 1
                        tilemap[enemyPos[1]][enemyPos[0]] = TRAP
                        enemyPos = [9,9] 
            if event.key == K_c:
                if tilemap[playerPos[1]][playerPos[0]] == GOLD:
                    inventory[GOLD] += 1
                    tilemap[playerPos[1]][playerPos[0]] = GRASS
                    tilemap[0][0] = EXIT
            if event.key == K_v:
                if tilemap[playerPos[1]][playerPos[0]] == WEAPON:
                    inventory[WEAPON] += 1
                    tilemap[playerPos[1]][playerPos[0]] = FLOOR
    for row in range(MAPHEIGHT):
        for column in range(MAPWIDTH):
            win_sur.blit(textures[tilemap[row][column]], (column*TILESIZE, row*TILESIZE))
    #display player and enemy
    win_sur.blit(HERO, (playerPos[0]*TILESIZE, playerPos[1]*TILESIZE))
    win_sur.blit(ENEMY, (enemyPos[0]*TILESIZE, enemyPos[1]*TILESIZE))
    
    
    #display inventory on top bottom of screen
    placePos = 0
    for item in resources:
        win_sur.blit(textures[item], (placePos, MAPHEIGHT*TILESIZE))
        placePos += 50
        textObj = INVFONT.render(str(inventory[item]), True, BLACK, WHITE)
        win_sur.blit(textObj, (placePos, MAPHEIGHT*TILESIZE+10))
        placePos += 10
    
    pygame.display.update()


    #win game
    if inventory[GOLD] == 1:
        if tilemap[playerPos[1]][playerPos[0]] == EXIT:
            print("You Win!!!")
            sleep(1)
            pygame.quit()
            sys.exit()        


    #game over
    if tilemap[playerPos[1]][playerPos[0]] == TRAP:
        print("Game Over!!!")
        sleep(1)
        pygame.quit()
        sys.exit()

